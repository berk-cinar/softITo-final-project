import { SituationInside } from "./SituationInside"

export const SituationOutside = () => {
  return (
    <div>
        <h1>Dışarıda</h1>
        <SituationInside/>
    </div>
  )
}